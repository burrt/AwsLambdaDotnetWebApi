# .NET LTS Web API

![Build Status](https://github.com/burrt/AwsLambdaDotnetWebApi/actions/workflows/cicd.yml/badge.svg?branch=main)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=burrt_AwsLambdaDotnetWebApi&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=burrt_AwsLambdaDotnetWebApi)
[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=burrt_AwsLambdaDotnetWebApi&metric=coverage)](https://sonarcloud.io/summary/new_code?id=burrt_AwsLambdaDotnetWebApi)

A template for .NET LTS Web API apps hosted in AWS Lambda. Attempting to incorporate most of [the user libraries documented here](https://burrt.github.io/compsci-docs/v1/cs-tools/).

Deployed with an API Gateway backed by the Lambda!
